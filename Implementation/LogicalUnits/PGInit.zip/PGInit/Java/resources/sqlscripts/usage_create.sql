DROP TABLE IF EXISTS public.cycle_control CASCADE;
DROP TABLE IF EXISTS public.usage1 CASCADE;
DROP TABLE IF EXISTS public.usage2 CASCADE;
DROP TABLE IF EXISTS public.usage3 CASCADE;
DROP TABLE IF EXISTS public.usage4 CASCADE;
DROP TABLE IF EXISTS public.usage5 CASCADE;

    CREATE TABLE public.cycle_control (
		cycle_code numeric(38,0) NOT NULL,
		cycle_month numeric(38,0) NOT NULL,
		table_name character varying(200)
	);


	ALTER TABLE public.cycle_control OWNER TO USAGE_USER;

	CREATE TABLE public.usage1 (
		customer_id numeric(38,0) NOT NULL,
		usage_id numeric(38,0) NOT NULL,
		usage_amt numeric(38,0)
	);


	ALTER TABLE public.usage1 OWNER TO USAGE_USER;


	CREATE TABLE public.usage2 (
		customer_id numeric(38,0) NOT NULL,
		usage_id numeric(38,0) NOT NULL,
		usage_amt numeric(38,0)
	);


	ALTER TABLE public.usage2 OWNER TO USAGE_USER;


	CREATE TABLE public.usage3 (
		customer_id numeric(38,0) NOT NULL,
		usage_id numeric(38,0) NOT NULL,
		usage_amt numeric(38,0)
	);


	ALTER TABLE public.usage3 OWNER TO USAGE_USER;


	CREATE TABLE public.usage4 (
		customer_id numeric(38,0) NOT NULL,
		usage_id numeric(38,0) NOT NULL,
		usage_amt numeric(38,0)
	);


	ALTER TABLE public.usage4 OWNER TO USAGE_USER;


	CREATE TABLE public.usage5 (
		customer_id numeric(38,0) NOT NULL,
		usage_id numeric(38,0) NOT NULL,
		usage_amt numeric(38,0)
	);


	ALTER TABLE public.usage5 OWNER TO USAGE_USER;


	ALTER TABLE ONLY public.cycle_control
		ADD CONSTRAINT cycle_control_pkey PRIMARY KEY (cycle_code, cycle_month);

	ALTER TABLE ONLY public.usage1
		ADD CONSTRAINT usage1_pkey PRIMARY KEY (customer_id, usage_id);

	ALTER TABLE ONLY public.usage2
		ADD CONSTRAINT usage2_pkey PRIMARY KEY (customer_id, usage_id);

	ALTER TABLE ONLY public.usage3
		ADD CONSTRAINT usage3_pkey PRIMARY KEY (customer_id, usage_id);

	ALTER TABLE ONLY public.usage4
		ADD CONSTRAINT usage4_pkey PRIMARY KEY (customer_id, usage_id);


	ALTER TABLE ONLY public.usage5
		ADD CONSTRAINT usage5_pkey PRIMARY KEY (customer_id, usage_id);


DROP SEQUENCE IF EXISTS public.usage1_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage2_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage3_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage4_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage5_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.log_usage_pk_seq CASCADE;

-- Create sequences for each table's primary key with a range from 1 to 9999999
CREATE SEQUENCE public.usage1_pk_seq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999 CACHE 1;
CREATE SEQUENCE public.usage2_pk_seq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999 CACHE 1;
CREATE SEQUENCE public.usage3_pk_seq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999 CACHE 1;
CREATE SEQUENCE public.usage4_pk_seq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999 CACHE 1;
CREATE SEQUENCE public.usage5_pk_seq START WITH 1 INCREMENT BY 1 MINVALUE 1 MAXVALUE 9999999 CACHE 1;

-- Modify the primary key column in each table to use the sequence as default
ALTER TABLE public.usage1 ALTER COLUMN usage_id SET DEFAULT nextval('public.usage1_pk_seq');
ALTER TABLE public.usage2 ALTER COLUMN usage_id SET DEFAULT nextval('public.usage2_pk_seq');
ALTER TABLE public.usage3 ALTER COLUMN usage_id SET DEFAULT nextval('public.usage3_pk_seq');
ALTER TABLE public.usage4 ALTER COLUMN usage_id SET DEFAULT nextval('public.usage4_pk_seq');
ALTER TABLE public.usage5 ALTER COLUMN usage_id SET DEFAULT nextval('public.usage5_pk_seq');

