DROP TABLE IF EXISTS public.entity_services CASCADE;
DROP TABLE IF EXISTS public.services CASCADE;
DROP TABLE IF EXISTS public.activity CASCADE;
DROP TABLE IF EXISTS public.address CASCADE;
DROP TABLE IF EXISTS public.balance CASCADE;
DROP TABLE IF EXISTS public.case_note CASCADE;
DROP TABLE IF EXISTS public.cases CASCADE;
DROP TABLE IF EXISTS public.contact_link CASCADE;
DROP TABLE IF EXISTS public.contact CASCADE;
DROP TABLE IF EXISTS public.contract_offer_mapping CASCADE;
DROP TABLE IF EXISTS public.contract CASCADE;
DROP TABLE IF EXISTS public.customer CASCADE;
DROP TABLE IF EXISTS public.invoice CASCADE;
DROP TABLE IF EXISTS public.offer CASCADE;
DROP TABLE IF EXISTS public.payment CASCADE;
DROP TABLE IF EXISTS public.subscriber CASCADE;

CREATE TABLE IF NOT EXISTS public.activity (
    customer_id numeric(38,0) NOT NULL,
    activity_id numeric(38,0) NOT NULL,
    activity_date timestamp without time zone,
    activity_note character varying(2000)
);

CREATE TABLE IF NOT EXISTS public.address (
    customer_id numeric(38,0) NOT NULL,
    address_id numeric(38,0) NOT NULL,
    street_address_1 character varying(200),
    street_address_2 character varying(200),
    city character varying(200),
    zip character varying(200),
    state character varying(200),
    country character varying(200)
);

CREATE TABLE IF NOT EXISTS public.balance (
    subscriber_id numeric(38,0) NOT NULL,
    balance_id numeric(38,0) NOT NULL,
    balance_ref_id numeric(38,0),
    available_amount numeric(38,0),
    reset_amount numeric(38,0),
    reset_date timestamp without time zone
);

CREATE TABLE IF NOT EXISTS public.case_note (
    case_id numeric(38,0) NOT NULL,
    note_id numeric(38,0) NOT NULL,
    note_date timestamp without time zone,
    note_text character varying(3000)
);

CREATE TABLE IF NOT EXISTS public.cases (
    activity_id numeric(38,0),
    case_id numeric(38,0) NOT NULL,
    case_date timestamp without time zone,
    case_type character varying(200),
    status character varying(200)
);

CREATE TABLE IF NOT EXISTS public.contact (
    contact_id numeric(38,0) NOT NULL,
    first_name character varying(200),
    last_name character varying(200),
    email character varying(200)
);


CREATE TABLE IF NOT EXISTS public.contact_link (
    customer_id numeric(38,0) NOT NULL,
    contact_id numeric(38,0) NOT NULL,
    contact_type character(1)
);


CREATE TABLE IF NOT EXISTS public.contract (
    customer_id numeric(38,0),
    contract_id numeric(38,0) NOT NULL,
    associated_line character varying(200),
    contract_description character varying(200),
    from_date timestamp without time zone,
    to_date timestamp without time zone,
    associated_line_fmt character varying(200),
    reference_contract_id double precision
);


CREATE TABLE IF NOT EXISTS public.contract_offer_mapping (
    contract_ref_id numeric(38,0),
    order_ref_id numeric(38,0),
    offer_contract_description character varying(200)
);


CREATE TABLE IF NOT EXISTS public.customer (
    customer_id numeric(38,0) NOT NULL,
    ssn character varying(20),
    first_name character varying(200),
    last_name character varying(200),
    bill_cycle double precision
);


CREATE TABLE IF NOT EXISTS public.invoice (
    subscriber_id numeric(38,0),
    invoice_id numeric(38,0) NOT NULL,
    issued_date timestamp without time zone,
    due_date timestamp without time zone,
    status character varying(2000),
    balance numeric(38,0),
    invoice_image character varying(2000)
);


CREATE TABLE IF NOT EXISTS public.offer (
    subscriber_id numeric(38,0),
    offer_id numeric(38,0),
    offer_ref_id numeric(38,0),
    offer_description character varying(200),
    from_date timestamp without time zone,
    to_date timestamp without time zone
);


CREATE TABLE IF NOT EXISTS public.payment (
    invoice_id numeric(38,0),
    payment_id numeric(38,0) NOT NULL,
    issued_date timestamp without time zone,
    status character varying(200),
    amount character varying(200)
);


CREATE TABLE IF NOT EXISTS public.subscriber (
    subscriber_id numeric(38,0) NOT NULL,
    msisdn character varying(200),
    imsi character varying(200),
    sim character varying(200),
    first_name character varying(200),
    last_name character varying(200),
    subscriber_type character varying(200),
    vip_status character varying(200)
);

CREATE TABLE IF NOT EXISTS public.services (
    service_id INT,
    service_code VARCHAR(50),
    service_name VARCHAR(255),
    description TEXT,
    price DECIMAL(10, 2),
    currency VARCHAR(10),
    service_type VARCHAR(100),
    status VARCHAR(50),
    start_date DATE,
    end_date DATE,
    billing_frequency VARCHAR(50),
    data_allowance DECIMAL(10, 2),
    voice_minutes INT,
    sms_allowance INT,
    service_provider VARCHAR(100),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.entity_services (
    entity_service_id INT,
    entity_id numeric(38,0),  -- Assuming this references customer_id or subscriber_id
    service_id INT,
    activation_date DATE,
    deactivation_date DATE,
    status VARCHAR(50),
    billing_amount DECIMAL(10, 2),
    billing_currency VARCHAR(10),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

ALTER TABLE public.activity OWNER TO CRM_USER_TAR;
ALTER TABLE public.address OWNER TO CRM_USER_TAR;
ALTER TABLE public.balance OWNER TO CRM_USER_TAR;
ALTER TABLE public.case_note OWNER TO CRM_USER_TAR;
ALTER TABLE public.cases OWNER TO CRM_USER_TAR;
ALTER TABLE public.contact OWNER TO CRM_USER_TAR;
ALTER TABLE public.contact_link OWNER TO CRM_USER_TAR;
ALTER TABLE public.contract OWNER TO CRM_USER_TAR;
ALTER TABLE public.contract_offer_mapping OWNER TO CRM_USER_TAR;
ALTER TABLE public.customer OWNER TO CRM_USER_TAR;
ALTER TABLE public.invoice OWNER TO CRM_USER_TAR;
ALTER TABLE public.offer OWNER TO CRM_USER_TAR;
ALTER TABLE public.payment OWNER TO CRM_USER_TAR;
ALTER TABLE public.subscriber OWNER TO CRM_USER_TAR;


ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_pk PRIMARY KEY (activity_id);

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (customer_id, address_id);

ALTER TABLE ONLY public.balance
    ADD CONSTRAINT balance_pkey PRIMARY KEY (subscriber_id, balance_id);

ALTER TABLE ONLY public.case_note
    ADD CONSTRAINT case_note_pkey PRIMARY KEY (case_id, note_id);

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (case_id);

ALTER TABLE ONLY public.contact_link
    ADD CONSTRAINT contact_link_pkey PRIMARY KEY (customer_id, contact_id);

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT contact_pkey PRIMARY KEY (contact_id);

ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_pkey PRIMARY KEY (contract_id);

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (customer_id);

ALTER TABLE ONLY public.invoice
    ADD CONSTRAINT invoice_pkey PRIMARY KEY (invoice_id);

ALTER TABLE ONLY public.payment
    ADD CONSTRAINT payment_pkey PRIMARY KEY (payment_id);

ALTER TABLE ONLY public.subscriber
    ADD CONSTRAINT subscriber_pkey PRIMARY KEY (subscriber_id);

CREATE UNIQUE INDEX contact_link_uq ON public.contact_link USING btree (contact_id);

ALTER TABLE public.services OWNER TO CRM_USER;
ALTER TABLE public.entity_services OWNER TO CRM_USER;

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (service_id);

ALTER TABLE ONLY public.entity_services
    ADD CONSTRAINT entity_services_pkey PRIMARY KEY (entity_service_id);

ALTER TABLE ONLY public.entity_services
    ADD CONSTRAINT entity_services_fk1 FOREIGN KEY (entity_id) REFERENCES public.customer(customer_id);

ALTER TABLE ONLY public.entity_services
    ADD CONSTRAINT entity_services_fk2 FOREIGN KEY (service_id) REFERENCES public.services(service_id);

ALTER TABLE ONLY public.activity
    ADD CONSTRAINT activity_fk1 FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_fk1 FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);


ALTER TABLE ONLY public.case_note
    ADD CONSTRAINT case_note_fk1 FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_fk1 FOREIGN KEY (activity_id) REFERENCES public.activity(activity_id);


ALTER TABLE ONLY public.contract
    ADD CONSTRAINT contract_fk1 FOREIGN KEY (customer_id) REFERENCES public.customer(customer_id);

ALTER TABLE ONLY public.contact
    ADD CONSTRAINT fk_contact_link FOREIGN KEY (contact_id) REFERENCES public.contact_link(contact_id);


DROP SEQUENCE IF EXISTS public.activity_id_seq;
DROP SEQUENCE IF EXISTS public.customer_id_seq;
DROP SEQUENCE IF EXISTS public.address_id_seq;
DROP SEQUENCE IF EXISTS public.subscriber_id_seq;
DROP SEQUENCE IF EXISTS public.balance_id_seq;
DROP SEQUENCE IF EXISTS public.case_id_seq;
DROP SEQUENCE IF EXISTS public.note_id_seq;
DROP SEQUENCE IF EXISTS public.contact_id_seq;
DROP SEQUENCE IF EXISTS public.contract_id_seq;
DROP SEQUENCE IF EXISTS public.invoice_id_seq;
DROP SEQUENCE IF EXISTS public.payment_id_seq;

CREATE seqUENCE public.activity_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.customer_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.address_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.subscriber_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.balance_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.case_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.note_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.contact_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.contract_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.invoice_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE seqUENCE public.payment_id_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
