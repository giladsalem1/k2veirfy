DROP TABLE IF EXISTS public.cycle_control CASCADE;
DROP TABLE IF EXISTS public.usage1 CASCADE;
DROP TABLE IF EXISTS public.usage2 CASCADE;
DROP TABLE IF EXISTS public.usage3 CASCADE;
DROP TABLE IF EXISTS public.usage4 CASCADE;
DROP TABLE IF EXISTS public.usage5 CASCADE;
DROP TABLE IF EXISTS public.log_usage CASCADE;

CREATE TABLE public.cycle_control (
    cycle_code numeric(38,0) NOT NULL,
    cycle_month numeric(38,0) NOT NULL,
    table_name character varying(200)
);


ALTER TABLE public.cycle_control OWNER TO USAGE_USER_TAR;

CREATE TABLE public.log_usage (
    log_id bigint NOT NULL,
    table_name character varying(30),
    operation character varying(10),
    old_customer_id numeric(38,0),
    new_customer_id numeric(38,0),
    old_usage_id numeric(38,0),
    new_usage_id numeric(38,0),
    old_usage_amt numeric(38,0),
    new_usage_amt numeric(38,0),
    log_timestamp timestamp(6) without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.log_usage OWNER TO USAGE_USER_TAR;

CREATE SEQUENCE public.log_usage_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.log_usage_log_id_seq OWNER TO USAGE_USER_TAR;

ALTER SEQUENCE public.log_usage_log_id_seq OWNED BY public.log_usage.log_id;


CREATE TABLE public.usage1 (
    customer_id numeric(38,0) NOT NULL,
    usage_id numeric(38,0) NOT NULL,
    usage_amt numeric(38,0)
);


ALTER TABLE public.usage1 OWNER TO USAGE_USER_TAR;

CREATE TABLE public.usage2 (
    customer_id numeric(38,0) NOT NULL,
    usage_id numeric(38,0) NOT NULL,
    usage_amt numeric(38,0)
);

ALTER TABLE public.usage2 OWNER TO USAGE_USER_TAR;

CREATE TABLE public.usage3 (
    customer_id numeric(38,0) NOT NULL,
    usage_id numeric(38,0) NOT NULL,
    usage_amt numeric(38,0)
);


ALTER TABLE public.usage3 OWNER TO USAGE_USER_TAR;

CREATE TABLE public.usage4 (
    customer_id numeric(38,0) NOT NULL,
    usage_id numeric(38,0) NOT NULL,
    usage_amt numeric(38,0)
);

ALTER TABLE public.usage4 OWNER TO USAGE_USER_TAR;

CREATE TABLE public.usage5 (
    customer_id numeric(38,0) NOT NULL,
    usage_id numeric(38,0) NOT NULL,
    usage_amt numeric(38,0)
);


ALTER TABLE public.usage5 OWNER TO USAGE_USER_TAR;

DROP SEQUENCE IF EXISTS public.usage1_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage2_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage3_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage4_pk_seq CASCADE;
DROP SEQUENCE IF EXISTS public.usage5_pk_seq CASCADE;

-- Create sequences for each table's primary key with a range from 10,000,000 to 99,999,999
CREATE SEQUENCE public.usage1_pk_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE SEQUENCE public.usage2_pk_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE SEQUENCE public.usage3_pk_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE SEQUENCE public.usage4_pk_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;
CREATE SEQUENCE public.usage5_pk_seq START WITH 10000000 INCREMENT BY 1 MINVALUE 10000000 MAXVALUE 99999999 CACHE 1;



CREATE OR REPLACE FUNCTION log_usage_changes() RETURNS TRIGGER AS $$ BEGIN IF (TG_OP = 'DELETE') THEN INSERT INTO public.log_usage (table_name, operation, old_customer_id, new_customer_id, old_usage_id, new_usage_id, old_usage_amt, new_usage_amt) VALUES (TG_TABLE_NAME, TG_OP, OLD.customer_id, NULL, OLD.usage_id, NULL, OLD.usage_amt, NULL); PERFORM pg_sleep(1); RETURN OLD; ELSIF (TG_OP = 'UPDATE') THEN INSERT INTO public.log_usage (table_name, operation, old_customer_id, new_customer_id, old_usage_id, new_usage_id, old_usage_amt, new_usage_amt) VALUES (TG_TABLE_NAME, TG_OP, OLD.customer_id, NEW.customer_id, OLD.usage_id, NEW.usage_id, OLD.usage_amt, NEW.usage_amt); PERFORM pg_sleep(1); RETURN NEW; ELSIF (TG_OP = 'INSERT') THEN INSERT INTO public.log_usage (table_name, operation, old_customer_id, new_customer_id, old_usage_id, new_usage_id, old_usage_amt, new_usage_amt) VALUES (TG_TABLE_NAME, TG_OP, NULL, NEW.customer_id, NULL, NEW.usage_id, NULL, NEW.usage_amt); PERFORM pg_sleep(1); RETURN NEW; END IF; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER usage1_insert_log AFTER INSERT ON public.usage1 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage1_update_log AFTER UPDATE ON public.usage1 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage1_delete_log AFTER DELETE ON public.usage1 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();

CREATE TRIGGER usage2_insert_log AFTER INSERT ON public.usage2 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage2_update_log AFTER UPDATE ON public.usage2 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage2_delete_log AFTER DELETE ON public.usage2 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();

CREATE TRIGGER usage3_insert_log AFTER INSERT ON public.usage3 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage3_update_log AFTER UPDATE ON public.usage3 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage3_delete_log AFTER DELETE ON public.usage3 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();

CREATE TRIGGER usage4_insert_log AFTER INSERT ON public.usage4 FOR EACH ROW EXECUTE FUNCTION log_usage_changes(); 
CREATE TRIGGER usage4_update_log AFTER UPDATE ON public.usage4 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage4_delete_log AFTER DELETE ON public.usage4 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();

CREATE TRIGGER usage5_insert_log AFTER INSERT ON public.usage5 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();
CREATE TRIGGER usage5_update_log AFTER UPDATE ON public.usage5 FOR EACH ROW EXECUTE FUNCTION log_usage_changes(); 
CREATE TRIGGER usage5_delete_log AFTER DELETE ON public.usage5 FOR EACH ROW EXECUTE FUNCTION log_usage_changes();

CREATE OR REPLACE FUNCTION delete_usage(i_usage_table VARCHAR, i_usage_id NUMERIC) RETURNS VOID LANGUAGE plpgsql AS $$ BEGIN EXECUTE format('DELETE FROM %I WHERE usage_id = $1', i_usage_table) USING i_usage_id; END; $$;
